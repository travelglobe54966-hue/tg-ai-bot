"""
Bot handlers package initialization.
"""
